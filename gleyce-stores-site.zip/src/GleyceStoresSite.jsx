import React from "react";

export default function GleyceStoresSite() {
  return (
    <div className="min-h-screen bg-gray-100 text-gray-800 p-6">
      <header className="bg-gradient-to-r from-pink-400 to-rose-500 text-white p-10 rounded-2xl shadow-xl mb-10 text-center">
        <h1 className="text-5xl font-extrabold mb-3 tracking-wide">Gleyce Stores</h1>
        <p className="text-xl opacity-90">Moda, Estilo e Elegância para Você</p>
        <button className="mt-6 px-6 py-3 bg-white text-pink-600 font-semibold rounded-xl shadow hover:scale-105 transition">
          Comprar Agora
        </button>
      </header>

      <section className="text-center mb-10">
        <div className="inline-block bg-white rounded-full shadow-xl p-6">
          <span className="text-4xl font-bold text-pink-500">GS</span>
        </div>
        <p className="mt-3 text-lg text-gray-600">Sua loja oficial de estilo</p>
      </section>

      <nav className="bg-white p-4 rounded-2xl shadow mb-10 flex justify-center gap-6 text-lg font-medium">
        <a href="#home" className="hover:text-pink-600">Home</a>
        <a href="#produtos" className="hover:text-pink-600">Produtos</a>
        <a href="#sobre" className="hover:text-pink-600">Sobre</a>
        <a href="#contato" className="hover:text-pink-600">Contato</a>
      </nav>

      <section id="produtos" className="mb-14">
        <h2 className="text-3xl font-bold mb-6 text-center">Produtos em Destaque</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-white p-4 rounded-2xl shadow hover:scale-105 transition">
              <img
                src={`https://via.placeholder.com/400x500?text=Produto+${i + 1}`}
                alt={`Produto ${i + 1}`}
                className="rounded-xl mb-4 w-full"
              />
              <h3 className="text-xl font-semibold mb-2">Produto {i + 1}</h3>
              <p className="mb-2">Descrição breve do produto.</p>
              <p className="font-bold text-pink-600 mb-4">R$ 99,90</p>
              <button className="px-4 py-2 bg-pink-500 text-white rounded-xl shadow">
                Ver Detalhes
              </button>
            </div>
          ))}
        </div>
      </section>

      <section id="produto-individual" className="bg-white p-8 rounded-2xl shadow mb-14">
        <h2 className="text-3xl font-bold mb-6 text-center">Detalhes do Produto</h2>
        <div className="grid md:grid-cols-2 gap-10">
          <img
            src="https://via.placeholder.com/500x600?text=Produto+Individual"
            alt="Produto Individual"
            className="rounded-2xl shadow"
          />
          <div>
            <h3 className="text-3xl font-bold mb-4">Vestido Floral</h3>
            <p className="text-gray-700 mb-4">
              Perfeito para ocasiões especiais, com tecido leve e confortável.
            </p>
            <p className="text-2xl font-bold text-pink-600 mb-6">R$ 149,90</p>
            <button className="px-6 py-3 bg-pink-500 text-white rounded-xl shadow">
              Adicionar ao Carrinho
            </button>
          </div>
        </div>
      </section>

      <section id="carrinho" className="bg-white p-8 rounded-2xl shadow mb-14">
        <h2 className="text-3xl font-bold mb-6 text-center">Carrinho de Compras</h2>
        <p className="text-center text-gray-500">Seu carrinho está vazio.</p>
      </section>

      <footer id="contato" className="text-center mt-10 text-sm text-gray-600 p-6 bg-white rounded-2xl shadow">
        <p>© {new Date().getFullYear()} Gleyce Stores — Todos os direitos reservados.</p>
        <p className="mt-2">Instagram | WhatsApp | Facebook</p>
      </footer>
    </div>
  );
}
